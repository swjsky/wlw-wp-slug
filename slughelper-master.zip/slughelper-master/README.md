slughelper
==========

从http://slughelper.codeplex.com/ fork而来，解决生成slug页面点取消却继续发布博文的bug。

详见http://blchen.com/fix-windstyle-slughelper-for-windows-live-writer-bug-not-cancel-publish/