﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WindStyle.WindowsLiveWriter.Plugin.SlugHelper
{
    public class BlogPost
    {
        public string Title { get; set; }

        public string Slug { get; set; }
    }
}
